package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.demo.ShoppingCart;
@SpringBootTest
class RsdApplicationTests {
	

	@Test
    public void testGetNetPayableAmount_NoPercentageDiscount() {
        ShoppingCart cart = new ShoppingCart();
        List g=new ArrayList<Item>();
        g.add(new Item("Item 1",100,Category.GROCERIES));
	    g.add(new Item("Item 2",200,Category.GROCERIES));
	    g.add(new Item("Item 3",300,Category.GROCERIES));
	    g.add(new Item("Item 4",400,Category.GROCERIES));
        cart.setItems(g);
        User user = new User();
        user.setEmployee(true);
        cart.setUser(user);

        assertEquals(950, cart.getNetPayableAmount());
    }

    @Test
    public void testGetNetPayableAmount_EmployeeDiscount() {
    	ShoppingCart cart = new ShoppingCart();
        List g=new ArrayList<Item>();
        g.add(new Item("Item 1",100,Category.OTHER));
	    g.add(new Item("Item 2",200,Category.OTHER));
	    g.add(new Item("Item 3",300,Category.OTHER));
	    g.add(new Item("Item 4",400,Category.OTHER));
        cart.setItems(g);
        User user = new User();
        user.setEmployee(true);
        cart.setUser(user);

        assertEquals(700, cart.getNetPayableAmount());
    }
    @Test
    public void testGetNetPayableAmount_AffiliateDiscount() {
    	ShoppingCart cart = new ShoppingCart();
        List g=new ArrayList<Item>();
        g.add(new Item("Item 1",100,Category.OTHER));
	    g.add(new Item("Item 2",200,Category.OTHER));
	    g.add(new Item("Item 3",300,Category.OTHER));
	    g.add(new Item("Item 4",400,Category.OTHER));
        cart.setItems(g);
        User user = new User();
        user.setAffiliate(true);
        cart.setUser(user);

        assertEquals(900, cart.getNetPayableAmount());
    }
    @Test
    public void testGetNetPayableAmount_Customer2YearsDiscount() {
    	ShoppingCart cart = new ShoppingCart();
        List g=new ArrayList<Item>();
        g.add(new Item("Item 1",100,Category.OTHER));
	    g.add(new Item("Item 2",200,Category.OTHER));
	    g.add(new Item("Item 3",300,Category.OTHER));
	    g.add(new Item("Item 4",400,Category.OTHER));
        cart.setItems(g);
        User user = new User();
        user.setCustomerOver2Years(true);
        cart.setUser(user);

        assertEquals(950, cart.getNetPayableAmount());
    }
    @Test
    public void testGetNetPayableAmount_GroceriesAndOthersDiscount() {
    	ShoppingCart cart = new ShoppingCart();
        List g=new ArrayList<Item>();
        g.add(new Item("Item 1",100,Category.GROCERIES));
	    g.add(new Item("Item 2",200,Category.GROCERIES));
	    g.add(new Item("Item 3",300,Category.OTHER));
	    g.add(new Item("Item 4",400,Category.OTHER));
        cart.setItems(g);
        User user = new User();
        user.setEmployee(true);
        cart.setUser(user);

        assertEquals(775, cart.getNetPayableAmount());
    }

}
