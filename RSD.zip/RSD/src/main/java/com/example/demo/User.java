package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class User {
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isEmployee() {
		return isEmployee;
	}
	public void setEmployee(boolean isEmployee) {
		this.isEmployee = isEmployee;
	}
	public boolean isAffiliate() {
		return isAffiliate;
	}
	public void setAffiliate(boolean isAffiliate) {
		this.isAffiliate = isAffiliate;
	}
	public boolean isCustomerOver2Years() {
		return isCustomerOver2Years;
	}
	public void setCustomerOver2Years(boolean isCustomerOver2Years) {
		this.isCustomerOver2Years = isCustomerOver2Years;
	}
	private String name;
	private boolean isEmployee;
    private boolean isAffiliate;
    private boolean isCustomerOver2Years;
    public User() {
    	
    }


	
	public User(String name, boolean isEmployee, boolean isAffiliate, boolean isCustomerOver2Years) {
		super();
		this.name = name;
		this.isEmployee = isEmployee;
		this.isAffiliate = isAffiliate;
		this.isCustomerOver2Years = isCustomerOver2Years;
	}

    
}

