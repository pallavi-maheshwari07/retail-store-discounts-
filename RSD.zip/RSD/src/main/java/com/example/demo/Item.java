package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Item {
    
	private String name;
    private double price;
    private Category category;
    public Item() {
		
	}
    public Item(String name, double price, Category category) {
		super();
		this.name = name;
		this.price = price;
		this.category = category;
	}
	// Constructor, getters, and setters
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
}
