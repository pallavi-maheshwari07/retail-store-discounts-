package com.example.demo;

public enum Category {
    GROCERIES,
    OTHER
}