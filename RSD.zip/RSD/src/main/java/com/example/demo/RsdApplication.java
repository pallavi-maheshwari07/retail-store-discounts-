package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RsdApplication {

	public static void main(String[] args) {
		SpringApplication.run(RsdApplication.class, args);
		
		
		ShoppingCart cart = new ShoppingCart();
        List g=new ArrayList<Item>();
        g.add(new Item("Item 1",100,Category.GROCERIES));
	    g.add(new Item("Item 2",200,Category.GROCERIES));
	    g.add(new Item("Item 3",300,Category.OTHER));
	    g.add(new Item("Item 4",400,Category.OTHER));
        cart.setItems(g);
        User user = new User();
        user.setEmployee(true);
        cart.setUser(user);
        System.out.println("Net Amount="+cart.getNetPayableAmount());
	}

}
