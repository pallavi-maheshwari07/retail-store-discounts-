package com.example.demo;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class ShoppingCart {
    
	private List<Item> items;
	@Autowired
    private User user;
	private List<Item> groceries=null;
	private List<Item> othser=null;

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Item> getGroceries() {
		return groceries;
	}

	public void setGroceries(List<Item> groceries) {
		this.groceries = groceries;
	}

	public List<Item> getOthser() {
		return othser;
	}

	public void setOthser(List<Item> othser) {
		this.othser = othser;
	}


    public ShoppingCart() {
		
	}
    
    public double calculateTotal() {
        double total = 0;
        for (Item item : items) {
            total += item.getPrice();
        }
        return total;
    }
    public double calculateTotalGroceries() {
        double total = 0;
        for (Item item : groceries) {
            total += item.getPrice();
        }
        return total;
    }
    public double calculateTotalOthers() {
        double total = 0;
        for (Item item : othser) {
            total += item.getPrice();
        }
        return total;
    }

    

    public double applyDiscountsOnGroceries() {
        double totalDiscount = 0;
        if(groceries != null && user != null) {
        double totalGroceriesAmount = calculateTotalGroceries();
        totalDiscount += (int) (totalGroceriesAmount / 100) * 5;
        }
        return totalDiscount;
    }
    public double applyDiscountsOnOthers() {
        double totalDiscount = 0;
        
        double totalOthersAmount = calculateTotalOthers();
        
     // Apply percentage discounts
        if (othser != null && user != null) {
        	
            if (user.isEmployee()) {
                totalDiscount += 0.3 * totalOthersAmount;
                
            } else if (user.isAffiliate()) {
                totalDiscount += 0.1 * totalOthersAmount;
            } else if (user.isCustomerOver2Years()) {
                totalDiscount += 0.05 * totalOthersAmount;
            }
        }
        return totalDiscount;
    }



	public double getNetPayableAmount() {
		listSeperater();
        double totalAmount = calculateTotal();
        double totalDiscount = applyDiscountsOnGroceries()+ applyDiscountsOnOthers();
        return totalAmount - totalDiscount;
    }
	public void listSeperater() {
        groceries = new ArrayList<>();
        othser = new ArrayList<>();
        
        for (Item item : items) {
            if (item.getCategory() == Category.GROCERIES) {
                groceries.add(item);
            }
            if(item.getCategory()== Category.OTHER){
            	othser.add(item);
            }
            
        }
	}

	
}
